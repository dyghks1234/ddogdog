package com.example.service;

import com.example.domain.QnAReplyVO;

public interface ManageService {
	
	public void insertNcheck(QnAReplyVO vo);
}
