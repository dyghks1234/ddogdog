package com.example.service;

import com.example.domain.ReplyVO;

public interface ReplyService {
   public void insert(ReplyVO vo);
   public void delete(int rno);
}